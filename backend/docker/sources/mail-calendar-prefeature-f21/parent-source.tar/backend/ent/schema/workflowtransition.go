package schema

import (
	"entgo.io/ent"
	"entgo.io/ent/dialect/entsql"
	"entgo.io/ent/schema/edge"
	"entgo.io/ent/schema/field"
	"entgo.io/ent/schema/index"
	"github.com/google/uuid"
)

// WorkflowTransition — определение Ent-схемы сущности WorkflowTransition.
type WorkflowTransition struct {
	ent.Schema
}

// Поля сущности WorkflowTransition.
func (WorkflowTransition) Fields() []ent.Field {
	return []ent.Field{
		field.UUID("id", uuid.UUID{}).
			Default(uuid.New).
			Immutable(),
		field.Time("created_at").
			Default(nowUTC).
			Immutable(),
	}
}

// Mixin подключает VersionMixin (NFR-24 / ADR-ENT-VERSION-MIXIN-2026).
func (WorkflowTransition) Mixin() []ent.Mixin {
	return []ent.Mixin{
		VersionMixin{},
	}
}

// Рёбра (edges) сущности WorkflowTransition.
func (WorkflowTransition) Edges() []ent.Edge {
	return []ent.Edge{
		edge.From("from_status", WorkflowStatus.Type).
			Ref("from_transitions").
			Unique().
			Required(),
		// Cascade: hard-purge target status удаляет входящие переходы (A3W8-5-007 to_status).
		edge.To("to_status", WorkflowStatus.Type).
			Unique().
			Required().
			Annotations(entsql.OnDelete(entsql.Cascade)),
	}
}

// Индексы сущности WorkflowTransition.
func (WorkflowTransition) Indexes() []ent.Index {
	return []ent.Index{
		index.Edges("from_status", "to_status").
			Unique(),
	}
}
